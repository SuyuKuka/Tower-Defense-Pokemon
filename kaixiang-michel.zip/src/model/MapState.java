package model;

import model.InitWaves.Difficulty;
import characters.Max;
import characters.Ondine;
import characters.Pierre;
import characters.Rocket;
import characters.Sacha;
import characters.Starter;
import characters.Starter.Salameche;
import graphics.EnnemiPresent;
import graphics.GameScreen;
import graphics.GameoverScreen;
import graphics.UpdateMap;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.swing.Timer;
import static javax.swing.JLayeredPane.DRAG_LAYER;

public class MapState {
    private final Map m;
    private Hero selectedHero;
    private final int[][] config;
    private GameScreen screen;

    private final ArrayList<Tower> towerPresent = new ArrayList<Tower>();
    private final ArrayList<Ennemi> ennemiPresent = new ArrayList<Ennemi>();
    private ArrayList<ArrayList<Ennemi>> allEnnemis = new ArrayList<>();
    private ArrayList<Ennemi> wave = new ArrayList<>();
    private final Random rand = new Random();
    private Timer timer;

    private int pv = 3;
    private int limiteDeTemps = 30;
    private int gameSpeed = 50;
    private boolean pause = false;
    private double money;
    private double moneyIncrement = 0;
    private int nbTotalWave;
    private int nextWaveIn = 0;
    private int count = 0;
    private int step = 0;
    private int inc = 1;
    private int expWin = 0;
    private boolean endless;

    private final Difficulty diff;
    private InitWaves w;

    private double countMoney;
    private final ArrayList<Ennemi> ennemiEscaped = new ArrayList<>();

    public MapState(Difficulty difficulty, int mode) {
        Map map = new Map(18, 24, difficulty);
        m = map;
        config = m.getConfig();

        try {
            InitPokemon.loadingChar();
        } catch (FileNotFoundException ignored) {
        }
        diff = difficulty;
        w = new InitWaves(difficulty);
        if (difficulty == Difficulty.EASY) {
            limiteDeTemps = 40;
            money = 500;
        } else if (difficulty == Difficulty.NORMAL) {
            limiteDeTemps = 25;
            money = 200;
        } else if (difficulty == Difficulty.HARD) {
            limiteDeTemps = 10;
            money = 80;
        }
        countMoney = money;
        endless = mode == 1;
        if (!endless) {
            allEnnemis = w.getAllEnnemis();
        }
    }

    private void infoTerminal() {
        System.out.println(
                "===============================================================================================================");
        System.out.println(
                "Pour commencer à jouer, il faut placer une tours aux endroits qui contiennent des . sous la forme de coordonees");
        System.out.println(
                " - Exemple : F4 ou F04");
        System.out.println(
                "Vous avez 3 vies, il y a 6 vagues");
        System.out.println(
                "Si un ennemie passe sur la sortis S, vous perdez une vie, a 0 vie la partie est perdu");
        System.out.println(
                "===============================================================================================================");
    }

    public void startTerminal() throws FileNotFoundException {
        Scanner sc = new Scanner(System.in);
        int nbTour = 6;
        step = 0;
        int increment = 1;
        infoTerminal();

        Starter starterInstance = new Starter();
        Salameche sala = starterInstance.new Salameche();

        if (endless) {
            allEnnemis.add(w.initEndless(increment++));
        }

        while (!endGame() || endless) {
            if (endless && allEnnemis.size() == 1) {
                allEnnemis.add(w.initEndless(increment++));
            }

            for (ArrayList<Ennemi> eList : allEnnemis) {
                for (Ennemi e : eList) {
                    e.setMap(m);
                }
            }

            moveOnMap();
            loadNextWave();
            m.affiche(ennemiPresent);

            info(step);
            step = ennemiComing(step);
            step++;

            if (nbTour != 0) {
                System.out.print("Ajouter une tour  (" + nbTour + "): ");
                String st = sc.nextLine();
                if (!st.isEmpty()) {
                    if (setTower(sala.putTower(st), sala)) {
                        nbTour--;
                    }
                }
            }
            sala.attack(ennemiPresent, this);
        }
        sc.close();
    }

    private void info(int i) {
        System.out.println("Vagues restantes: " + (allEnnemis.size()));
        System.out.println("Ennemie en attente:" + wave.size());
        System.out.println("Ennemis sur le terrain: " + ennemiPresent.size());
        System.out.println("PV: " + pv);
        System.out.println("Temps avant la prochaine vague: " + (limiteDeTemps + 1 - i));
    }

    public void startGraphic(GameScreen s) throws FileNotFoundException {
        Pc.INSTANCE.setState(this);
        this.screen = s;

        screen.getMain().getMusicPlayer().setStartBattle(true);
        screen.getMain().getMusicPlayer().getClip().stop();
        Random rdm = new Random();
        int i = rdm.nextInt(6);
        screen.getMain().getMusicPlayer().playMusic("battle" + i);
        // MODE ENDLESS
        if (endless) {
            allEnnemis.add(w.initEndless(inc++));
            allEnnemis.add(w.initEndless(inc++));
            allEnnemis.add(w.initEndless(inc++));
            allEnnemis.add(w.initEndless(inc++));
        }
        //
        for (ArrayList<Ennemi> eList : allEnnemis) {
            for (Ennemi e : eList) {
                e.setMap(m);
                e.setTilesMap(m.getdirMap());
                screen.getuMap().setSpriteEntry(e);
                e.setPos(m.getEntry());
            }
        }

        if (selectedHero != null) {
            applyHero();
            screen.gettPresent().setHero(selectedHero);
        }

        nbTotalWave = allEnnemis.size();


        timer = new Timer(gameSpeed, event -> { // TIMEEEEEEEEEER
            // ENDLESS
            if (endless && allEnnemis.size() == 3) {
                allEnnemis.add(w.initEndless(inc++));
                for (ArrayList<Ennemi> eList : allEnnemis) {
                    for (Ennemi e : eList) {
                        e.setMap(m);
                        e.setTilesMap(m.getdirMap());
                        screen.getuMap().setSpriteEntry(e);
                        e.setPos(m.getEntry());
                    }
                }
            }
            //

            money = money + 0.01 * 1 + moneyIncrement;
            countMoney = countMoney + 0.01 * 1 + moneyIncrement;
            updateGraphic(nextWaveIn, false);
            moveOnMapGraphic(screen.getuMap());
            loadNextWave();
            step = ennemiComing(step);
            step++;
            nextWaveIn++;
            expWin++;
            //m.affiche(ennemiPresent);
            for (Tower t : towerPresent) {
                t.attack(ennemiPresent, this);
            }

            for (Ennemi e : screen.getePresent().getEnnemiGone()) {
                screen.getuMap().remove(e.getJLabelSprite());
            }

            if (endGame()) {
                allEnnemis.clear();
                ennemiPresent.clear();
                wave.clear();
                if (pv == 0) {
                    // System.out.println("VOUS AVEZ PERDU");
                    gameOverScreen(false);
                } else {
                    // System.out.println("VOUS AVEZ GAGNEE");
                    gameOverScreen(true);
                }
                timer.stop();
                screen.getMain().getMusicPlayer().setStartBattle(false);
                Player.INSTANCE.setExp(expWin / 150);
                while (Player.INSTANCE.getExp() >= Player.INSTANCE.expCap()) {
                    Player.INSTANCE.levelUp();
                }
            }
        });
        timer.start();

    }

    private boolean endGame() {
        if (allEnnemis.isEmpty() && !endless && ennemiPresent.isEmpty()) {
            return true;
        }
        return pv == 0;
    }

    public void removeFromMap(Tower pkm) {
        towerPresent.remove(pkm);
        m.remove(pkm);
        if (pkm.getTiles() != null) {
            screen.getuMap().getTiles(pkm.getPos()).resetTile();
            screen.getuMap().getGameMap().revalidate();
        }
    }

    private void gameOverScreen(boolean win) {
        updateGraphic(0, true);
        GameoverScreen fini = new GameoverScreen(this, screen, win);
        fini.revalidate();
        fini.repaint();
    }

    private int ennemiComing(int pas) {
        if (!wave.isEmpty()) {
            if (pas / 10 > rand.nextInt(600)) {
                setEnnemi(m.getEntry(), wave.get(0));
                wave.remove(0);
                return 0;
            }
        }
        return pas;
    }

    private void moveOnMap() {
        Ennemi escaped = null;
        boolean leaked = false;
        for (Ennemi e : ennemiPresent) {
            if (e.move()) {
                leaked = true;
                escaped = e;
            }
        }
        if (leaked && !ennemiPresent.isEmpty()) {
            ennemiPresent.remove(escaped);
            if (screen != null) {
                screen.getePresent().getEnnemiGone().add(escaped);
            }
            leaked = false;
            pv--;
        }
    }

    private void moveOnMapGraphic(UpdateMap uMap) {
        Ennemi escaped = null;
        boolean leaked = false;
        for (Ennemi e : ennemiPresent) {
            if (e.getProjectile() != null) {
                screen.getuMap().add(e.getProjectile(), DRAG_LAYER);
                e.getProjectile().updateProj();
            }
            e.getJLabelSprite().setVisible(true);
            if (e.moveGraphic(e.getJLabelSprite(), uMap)) {
                leaked = true;
                escaped = e;
                ennemiEscaped.add(e);
            }
        }
        if (leaked && !ennemiPresent.isEmpty()) {
            ennemiPresent.remove(escaped);
            if (screen != null) {
                screen.getePresent().getEnnemiGone().add(escaped);
            }
            leaked = false;
            pv--;
            if (screen != null) {
                screen.getuMap().repaint();
            }
        }
    }

    private void loadNextWave() {
        if (nextWaveIn > limiteDeTemps * 100 || ennemiPresent.isEmpty() && wave.isEmpty()) {
            count++;
            nextWaveIn = 0;
            for (Ennemi e : wave) {
                setEnnemi(m.getEntry(), e);
            }
            wave.clear();
            allEnnemis.remove(wave);
            moneyIncrement = moneyIncrement + 0.01;
        }
        if (!allEnnemis.isEmpty()) {
            wave = allEnnemis.get(0);
        }
    }

    public boolean setTower(int[] posTower, Tower tower) {
        if (posTower[0] != -1 && posTower[1] != -1) {
            // LA CONCEPTION DU TABLEAU EST DIFFERENTE, INVERSER I J
            int posX = posTower[0];
            int posY = posTower[1];
            if (config[posX][posY] == 0) {
                config[posX][posY] = 2;
                towerPresent.add(tower);
                tower.setPos(posTower);
                return true;
            }
        }
        return false;
    }

    private void setEnnemi(int[] posEnnemi, Ennemi ennemi) {
        int posX = posEnnemi[0];
        int posY = posEnnemi[1];
        if (config[posX][posY] == 3 || config[posX][posY] == 4) {
            ennemiPresent.add(ennemi);
            ennemi.setPos(posEnnemi);
        } else {
            return;
        }
    }

    public void isDead(Ennemi e) {
        screen.getuMap().repaint();
        if (e.isBoss()) {
            money = money + 100;
            countMoney = countMoney + 100;
            expWin += 3;
        } else {
            money = money + 10;
            countMoney = countMoney + 10;
            expWin += 0.1;
        }
        ennemiPresent.remove(e);
        if (screen != null) {
            screen.getePresent().getEnnemiGone().add(e);
        }
    }

    public void updateGraphic(int pas, boolean lose) {
        screen.getePresent().setEnnemiPresent(ennemiPresent);
        screen.getInGameInfo().updateInfo();
        screen.getInGameButton().updateButton(pas, limiteDeTemps, count, lose);
        for (Ennemi e : ennemiPresent) {
            EnnemiPresent.updateEnnemiHealth(e);
            screen.getePresent().updateSmallPanel(e);
        }
        for (Tower t : towerPresent) {
            showAlert(t);
        }
    }

    private void showAlert(Tower t) {
        if (t.getGUI().getAlert() && !t.getGUI().isVisible()) {
            t.getTiles().setBackground(Color.RED);
            t.getTiles().setOpaque(true);
        } else if (!t.getGUI().isVisible()) {
            t.getTiles().setOpaque(false);
        }
    }

    public ArrayList<Ennemi> getEnnemiPresent() {
        return ennemiPresent;
    }

    public ArrayList<Tower> getTowerPresent() {
        return towerPresent;
    }

    public Map getMap() {
        return m;
    }

    public ArrayList<ArrayList<Ennemi>> getAllEnnemis() {
        return allEnnemis;
    }

    public void setGameSpeed(int gameSpeed) {
        if (timer != null) {
            timer.setDelay(gameSpeed);
            timer.restart();
        }
        this.gameSpeed = gameSpeed;
    }

    public int getGameSpeed() {
        return gameSpeed;
    }

    public void setPause(boolean pause) {
        if (pause) {
            timer.stop();
        } else {
            timer.start();
        }
        this.pause = pause;
    }

    public boolean getPause() {
        return pause;
    }

    public double getMoney() {
        return money;
    }

    public int getPv() {
        return pv;
    }

    public int getNbTotalWave() {
        return nbTotalWave;
    }

    public boolean getEndless() {
        return endless;
    }

    public int getCount() {
        return count;
    }

    public double getCountMoney() {
        return countMoney;
    }

    public ArrayList<Ennemi> getEnnemiEscaped() {
        return ennemiEscaped;
    }

    public Difficulty getDiff() {
        return diff;
    }

    public Timer getTimer() {
        return timer;
    }

    public void setEndless(boolean endless) {
        this.endless = endless;
    }

    public int getInc() {
        return inc;
    }

    public void setInc(int inc) {
        this.inc = inc;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    private void applyHero() {
        ifBuff:
        for (ArrayList<Ennemi> eList : allEnnemis) {
            for (Ennemi e : eList) {
                if (selectedHero instanceof Sacha) {
                    ((Sacha) selectedHero).buff();
                    break ifBuff;
                }
                if (selectedHero instanceof Ondine) {
                    ((Ondine) selectedHero).buff();
                    break ifBuff;
                }
                if (selectedHero instanceof Pierre) {
                    if (e.isBoss()) {
                        ((Pierre) selectedHero).debuff(e);
                    }
                }
                if (selectedHero instanceof Max) {
                    if (e.isBoss()) {
                        ((Max) selectedHero).debuff(e);
                    }
                }
                if (selectedHero instanceof Rocket) {
                    ((Rocket) selectedHero).debuff(e);
                }
            }
        }

    }

    public void setSelectedHero(Hero selectedHero) {
        this.selectedHero = selectedHero;
    }
}
