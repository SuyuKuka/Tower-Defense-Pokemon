package characters;

import model.Skill;
import model.Tower;
import model.TowerLoader;
import model.Types;

public class Starter {
    public class Salameche extends Tower implements TowerLoader {
        public Salameche() {
            super("Salameche", 22, 38, Types.FEU, Types.NONE, "ressources/sprite/charmander/charmander.gif",
                    State.LOCKED, 30, Tower.Rayon.SMALL, 100);
            primarySkill();
        }

        public void reset() {
            setName("Salameche");
            setLevel(1);
            setPhysical(22);
            setSpecial(38);
            setAtkCd(50);
            setRayon(Tower.Rayon.SMALL);
            setPrice(100);
            setFirstType(Types.FEU);
            setSecondType(Types.NONE);
            setSprite("ressources/sprite/charmander/charmander.gif");
            setExp(0);
        }

        @Override
        public void evolution() {
            if (getLevel() == 15) {
                setSprite("ressources/sprite/charmander/charmeleon.gif");
                setName("Reptincel");
                setPhysical(getPhysical() + 10);
                setSpecial(getSpecial() + 10);
                setAtkCd(80);
                if (getTiles() != null) {
                    getTiles().replaceSprite(getSprite());
                }
            }
            if (getLevel() == 30) {
                setSprite("ressources/sprite/charmander/charizard.gif");
                setName("Dracaufeu");
                setPhysical(getPhysical() + 20);
                setSpecial(getSpecial() + 20);
                setSecondType(Types.VOL);
                setAtkCd(150);
                setRayon(Tower.Rayon.LARGE);
                if (getTiles() != null) {
                    getTiles().replaceSprite(getSprite());
                }
            }
        }

        @Override
        public void primarySkill() {
            learnSkill(new Skill("Griffe", 10, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 0));
        }

        @Override
        public void unlock() {
            if (getLevel() == 7) {
                learnSkill(new Skill("Flammeche", 0, 15, Types.FEU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 12) {
                learnSkill(new Skill("Draco-Rage", 0, 10, Types.DRAGON, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 16) {
                learnSkill(new Skill("Crocs Feu", 25, 0, Types.FEU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 25) {
                learnSkill(new Skill("Rebondifeu", 0, 35, Types.FEU, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 32) {
                learnSkill(new Skill("Cru-Aile", 30, 0, Types.VOL, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 36) {
                learnSkill(new Skill("Tranche", 50, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 43) {
                learnSkill(new Skill("Lame d'Air", 55, 0, Types.VOL, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 52) {
                learnSkill(new Skill("Boutefeu", 60, 0, Types.FEU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 60) {
                learnSkill(new Skill("Feu d'enfer", 0, 100, Types.FEU, Skill.Pattern.UNIQUE, "", 200));
            }
        }
    }

    public class Arcko extends Tower implements TowerLoader {
        public Arcko() {
            super("Arcko", 20, 40, Types.PLANTE, Types.NONE, "ressources/sprite/treecko/treecko.gif", State.LOCKED, 30,
                    Tower.Rayon.SMALL, 100);
            primarySkill();
        }

        public void reset() {
            setName("Arcko");
            setLevel(1);
            setPhysical(20);
            setSpecial(40);
            setAtkCd(50);
            setRayon(Tower.Rayon.SMALL);
            setPrice(100);
            setFirstType(Types.PLANTE);
            setSecondType(Types.NONE);
            setSprite("ressources/sprite/treecko/treecko.gif");
            setExp(0);
        }

        @Override
        public void evolution() {
            if (getLevel() == 16) {
                setSprite("ressources/sprite/treecko/grovyle.gif");
                setName("Massko");
                setPhysical(getPhysical() + 10);
                setSpecial(getSpecial() + 10);
                setRayon(Tower.Rayon.MEDIUM);
                if (getTiles() != null) {
                    getTiles().replaceSprite(getSprite());
                }
            }
            if (getLevel() == 36) {
                setSprite("ressources/sprite/treecko/sceptile.gif");
                setName("Jungko");
                setPhysical(getPhysical() + 20);
                setSpecial(getSpecial() + 20);
                if (getTiles() != null) {
                    getTiles().replaceSprite(getSprite());
                }
            }
        }

        @Override
        public void primarySkill() {
            learnSkill(new Skill("Ecras'Face", 10, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 0));
        }

        @Override
        public void unlock() {
            if (getLevel() == 6) {
                learnSkill(new Skill("Feuillage", 0, 15, Types.PLANTE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 9) {
                learnSkill(new Skill("Vive-Attaque", 10, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 16) {
                learnSkill(new Skill("Mega-Sangsue", 0, 25, Types.PLANTE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 23) {
                learnSkill(new Skill("Giga-Sangsue", 0, 35, Types.PLANTE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 31) {
                learnSkill(new Skill("Souplesse", 30, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 39) {
                learnSkill(new Skill("Lame-Feuille", 50, 0, Types.PLANTE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 44) {
                learnSkill(new Skill("Plaie Croix", 55, 0, Types.INSECTE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 52) {
                learnSkill(new Skill("Eco-Sphere", 0, 60, Types.PLANTE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 60) {
                learnSkill(new Skill("Tempete Verte", 0, 100, Types.PLANTE, Skill.Pattern.AURA, "", 200));
            }
        }
    }

    public class Moustillon extends Tower implements TowerLoader {
        public Moustillon() {
            super("Moustillon", 25, 35, Types.EAU, Types.NONE, "ressources/sprite/oshawott/oshawott.gif", State.LOCKED,
                    30, Tower.Rayon.SMALL, 100);
            primarySkill();
        }

        public void reset() {
            setName("Moustillon");
            setLevel(1);
            setPhysical(25);
            setSpecial(35);
            setAtkCd(50);
            setRayon(Tower.Rayon.SMALL);
            setPrice(100);
            setFirstType(Types.EAU);
            setSecondType(Types.NONE);
            setSprite("ressources/sprite/oshawott/oshawott.gif");
            setExp(0);
        }

        @Override
        public void evolution() {
            if (getLevel() == 16) {
                setSprite("ressources/sprite/oshawott/dewott.gif");
                setName("Mateloutre");
                setPhysical(getPhysical() + 10);
                setSpecial(getSpecial() + 10);
                if (getTiles() != null) {
                    getTiles().replaceSprite(getSprite());
                }
            }
            if (getLevel() == 36) {
                setSprite("ressources/sprite/oshawott/samurott.gif");
                setName("Clamiral");
                setPhysical(getPhysical() + 20);
                setSpecial(getSpecial() + 20);
                setRayon(Tower.Rayon.MEDIUM);
                if (getTiles() != null) {
                    getTiles().replaceSprite(getSprite());
                }
            }
        }

        @Override
        public void primarySkill() {
            learnSkill(new Skill("Ecras'Face", 10, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 200));
        }

        @Override
        public void unlock() {
            if (getLevel() == 5) {
                learnSkill(new Skill("Ecume", 0, 15, Types.EAU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 10) {
                learnSkill(new Skill("Vive-Attaque", 10, 0, Types.NORMAL, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 16) {
                learnSkill(new Skill("Coqui-Lame", 25, 0, Types.EAU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 22) {
                learnSkill(new Skill("Vibraqua", 0, 38, Types.EAU, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 27) {
                learnSkill(new Skill("Aeropique", 30, 0, Types.VOL, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 32) {
                learnSkill(new Skill("Aqua-Jet", 50, 0, Types.EAU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 46) {
                learnSkill(new Skill("Tranche-Nuit", 55, 0, Types.TENEBRE, Skill.Pattern.AURA, "", 200));
            }
            if (getLevel() == 52) {
                learnSkill(new Skill("Hydrocanon", 0, 60, Types.EAU, Skill.Pattern.UNIQUE, "", 200));
            }
            if (getLevel() == 60) {
                learnSkill(new Skill("Lame Sainte", 100, 0, Types.COMBAT, Skill.Pattern.UNIQUE, "", 200));
            }
        }
    }
}
